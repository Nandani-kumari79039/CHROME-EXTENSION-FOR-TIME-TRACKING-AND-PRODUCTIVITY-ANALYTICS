const mongoose = require("mongoose");

const UsageSchema = new mongoose.Schema({
  domain: String,
  timeSpent: Number,
  date: String
});

module.exports = mongoose.model("Usage", UsageSchema);
