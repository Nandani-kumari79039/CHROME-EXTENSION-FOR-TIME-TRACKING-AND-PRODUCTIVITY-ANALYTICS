document.getElementById("viewDashboard").addEventListener("click", () => {
  window.open("http://localhost:5000/dashboard", "_blank");
});
